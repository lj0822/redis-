package com.lagou.service;

public interface HelloService {
    public String sayHello(String name, int timeToWait);
}
